//: Playground - noun: a place where people can play

import UIKit

var date  = Date()
let format = DateFormatter()


// Predifined formats

print("Date's predifined formats")
format.timeStyle = DateFormatter.Style.none
format.dateStyle = DateFormatter.Style.short
print("Short date style => " + format.string(from: date))

format.dateStyle = DateFormatter.Style.medium
print("Medium date style => " + format.string(from: date))

format.dateStyle = DateFormatter.Style.long
print("Long date style => " + format.string(from: date))

format.dateStyle = DateFormatter.Style.full
print("Full date style => " + format.string(from: date))

print("")

print("Hour's predifined format")
format.dateStyle = DateFormatter.Style.none
format.timeStyle = DateFormatter.Style.short
print("Short time style => " + format.string(from: date))

format.timeStyle = DateFormatter.Style.medium
print("Medium time style => " + format.string(from: date))

format.timeStyle = DateFormatter.Style.long
print("Long time style => " + format.string(from: date))

format.timeStyle = DateFormatter.Style.full
print("Full time style => " + format.string(from: date))

print("")

print("Programmer formats")

var dateComponents = DateComponents()
dateComponents.year = 2016
dateComponents.month = 8
dateComponents.day = 17
dateComponents.hour = 12
dateComponents.minute = 45
dateComponents.second = 12

extension Date {
    func add(days: Int) -> Date {
        return Calendar.current.date(byAdding: .day, value: days, to: self)!
    }
    func add(weeks: Int) -> Date {
        let days = weeks * 7
        return Calendar.current.date(byAdding: .day, value: days, to: self)!
    }
}


let userCalendar = Calendar.current // user calendar
date = userCalendar.date(from: dateComponents)!

func dateByAddingDays(inDays:NSInteger)->Date{
    let today = Date()
    return Calendar.current.date(byAdding: .day, value: inDays, to: today)!
}

// 1. Wed, 17 Aug
format.dateFormat = "EEE, dd MMM"
print(format.string(from: date))

// 2. Wednesday August 17
format.dateFormat = "EEEE MMMM dd"
print(format.string(from: date))

// 3. 8/17/16, 12:45 PM
format.dateFormat = "M/dd/yy, h:mm a"
print(format.string(from: date))

// 4. 17 / Aug / 2016 ---  12 : 45 : 12
format.dateFormat = "dd / MMM / yyyy --- hh : mm : ss"
print(format.string(from: date))

// 5. Aug of 2016
format.dateFormat = "MMM 'of' yyyy"
print(format.string(from: date))

// 6. 17 / 08 / 16  at 12:45 PM
format.dateFormat = "dd / MM / yy 'at' h:mm a"
print(format.string(from: date))

// format for next exercises
format.dateFormat = "EEEE MMMM d"

// 7. Dia siguiente: Thursday August 18
let nextDay = date.add(days: 1)
print("Dia siguiente:",format.string(from: nextDay))

// 8. Dia anterior: Tuesday August 16
let lastDay = date.add(days: -1)
print("Dia anterior:",format.string(from: lastDay))

// 9. Semana siguiente: Wednesday August 24
let nextWeek = date.add(weeks: 1)
print("Semana anterior:",format.string(from: nextWeek))

// 10. Semana anterior: Wednesday August 10
let lastWeek = date.add(weeks: -1)
print("Semana anterior:",format.string(from: lastWeek))


